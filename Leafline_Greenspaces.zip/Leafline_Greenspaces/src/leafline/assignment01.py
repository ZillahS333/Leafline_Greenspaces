# %% [markdown]
# # **LOCATION OF URBAN GREEN AREAS TO MITIGATE URBAN HEAT ISLAND EFFECTS**

# %% [markdown]
# ##### **1. REQUIRED PYTHON LIBRARIES AND SOFTWARE DEPENDENCIES**

# %% [markdown]
# Main functionalities supported:
# - Numerical and tabular data handling using NumPy and Pandas  
# - Geospatial vector data processing and CRS management with GeoPandas  
# - Geometric constructions and spatial operations (Point, LineString, Polygon,
#   MultiPoint, concave hulls) using Shapely  
# - Efficient nearest-neighbor search and distance-based spatial queries using KDTree  
# - Spatial network analysis and routing using NetworkX and OSMnx  
# - Interaction with PostgreSQL/PostGIS databases using psycopg2 for spatial data I/O  
# - Interactive and exploratory data visualization using Plotly Express
# 
# This setup is suitable for projects involving spatial networks, service-area
# analysis, and exploratory geospatial data analysis in both Python-only and
# Python–PostGIS integrated workflows.

# %%
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple, TypedDict
from typing import Literal
import os

import numpy as np
import pandas as pd

import geopandas as gpd
import osmnx as ox
import networkx as nx
from scipy.spatial import cKDTree
from shapely.geometry import (
    Point, LineString, Polygon,
    MultiPoint, MultiLineString, MultiPolygon,
    mapping,
)
from shapely import concave_hull

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
import matplotlib.patches as mpatches
from matplotlib.ticker import ScalarFormatter

import folium
from IPython.display import display, HTML


# %% [markdown]
# ##### **2. DATA ACQUISITION AND CLEANING**

# %%
@dataclass(frozen=True)
class Config:
    crs_epsg: int = 25830

    # Area of Interest (AOI).
    district_col: str = "NOMBRE"
    district_name: str = "Centro"

    # Population column in population layer
    pop_col: str = "VALUE"

    # Walking speed and 5 min Isochrone
    walk_speed_kmh: float = 5.0
    t_min: int = 5

    # Candidate generation by neighborhood or random mode
    mode: Literal["neighborhood", "random"] = "neighborhood"
    neigh_col: str = "NOMBRE"
    pts_per_neigh: int = 10
    n_candidates_random: int = 50

    # Selection of candidates giving priority to top k but with distance constraint
    top_k: int = 2
    min_dist_m: float = 500.0

    # Geometry robustness
    hull_ratio: float = 0.10
    allow_holes: bool = True
    tiny_buffer: float = 0.0

    # Random seed for reproducibility
    seed: int = 42
    max_factor: int = 1200

    # Roads (Open Street Map API)
    roads_network_type: Literal["drive", "walk", "bike", "all"] = "drive"
    roads_simplify: bool = True

    # Output
    out_gpkg: str = "green_candidates_structured.gpkg"


def ensure_crs(gdf: gpd.GeoDataFrame, epsg: int) -> gpd.GeoDataFrame:
    """
    Ensure correct CRS for a GeoDataFrame. User specified EPSG code.

    Parameters
    ----------
    gdf : GeoDataFrame
        Input spatial dataset.
    epsg : int
        Target EPSG code.

    Returns
    -------
    GeoDataFrame
        GeoDataFrame in the specified coordinate reference system.
    """
    if gdf.crs is None:
        raise ValueError("GeoDataFrame has no CRS defined.")
    return gdf if gdf.crs.to_epsg() == epsg else gdf.to_crs(epsg=epsg)


def load_inputs(cfg: Config) -> Dict[str, gpd.GeoDataFrame]:
    """
    Loads input with the required CRS and fetches road network from OSM.

    Parameters
    ----------
    cfg : Config
        Configuration object containing CRS settings and road network parameters.

    Returns
    -------
    dict of GeoDataFrame
        Dictionary of input layers, including vegetation, boundaries,
        population, neighborhoods, buildings, and the road network.
    """

    layers = {
        "green": gpd.read_file("Input/Vegetation_Merged.shp"),
        "boundary": gpd.read_file("Input/DISTRITOS.shp"),
        "pop": gpd.read_file("Input/population.shp"),
        "neigh": gpd.read_file("Input/20240101_estructura_demografica_barrio.shp"),
        "buildings": gpd.read_file("Input/ALTURA_EDIFICIOS.shp"),
    }
    layers = {k: ensure_crs(v, cfg.crs_epsg) for k, v in layers.items()}

    aoi = build_aoi(layers["boundary"], cfg)  # AOI en EPSG:25830 (m)
    aoi_wgs = gpd.GeoSeries([aoi], crs=f"EPSG:{cfg.crs_epsg}").to_crs(4326).iloc[0]  # <-- CLAVE

    G = ox.graph_from_polygon(
        aoi_wgs,
        network_type=cfg.roads_network_type,
        simplify=cfg.roads_simplify
    )
    _, roads = ox.graph_to_gdfs(G)
    roads = roads.to_crs(epsg=cfg.crs_epsg)          # volver a 25830
    roads = roads[roads.geometry.notna() & ~roads.geometry.is_empty].copy()
    roads = gpd.clip(roads, aoi).copy()              # clip ya en 25830 (estable)

    layers["roads"] = roads
    return layers


def build_aoi(boundary: gpd.GeoDataFrame, cfg: Config):
    """
    Create the area of interest (AOI) from district boundaries into a single polygon (e.g., 'Centro').

    Parameters
    ----------
    boundary : GeoDataFrame
        District boundary polygons.
    cfg : Config
        Configuration object containing the district selection parameters.

    Returns
    -------
    shapely geometry
        Polygon representing the area of interest.

    """
    aoi = boundary[boundary[cfg.district_col] == cfg.district_name].geometry.union_all()
    return aoi.buffer(0)


def clip_and_add_id(gdf: gpd.GeoDataFrame, aoi, id_col: str) -> gpd.GeoDataFrame:
    """
    Input layers are clipped to the AOI and assigned unique IDs for easier handling and computation.

    Parameters
    ----------
    gdf : GeoDataFrame
        Input spatial dataset to be clipped.
    aoi : shapely geometry
        Area of interest used for clipping.
    id_col : str
        Name of the ID column to be added.

    Returns
    -------
    GeoDataFrame
        Clipped GeoDataFrame with an added unique ID column.
    """

    out = gpd.clip(gdf, aoi).copy()
    out = out.reset_index(drop=True)
    out[id_col] = np.arange(1, len(out) + 1)
    return out


def clean_sjoin(gdf: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    """
    Deletes leftover index columns from a spatial join and returns a cleaned GeoDataFrame.

    Parameters
    ----------
    gdf : GeoDataFrame
        GeoDataFrame resulting from a spatial join.

    Returns
    -------
    GeoDataFrame
        Cleaned GeoDataFrame without spatial join index columns.
    """

    return gdf.drop(
        columns=[c for c in gdf.columns if c.startswith("index_")],
        errors="ignore"
    )

# %%
#Configuration and data loading: required for all subsequent steps. Since data loading can be time-consuming, it is recommended to run this cell only once at the beginning (OSM).

cfg = Config()
data = load_inputs(cfg)

# AOI  (EPSG:25830)
aoi_geom = build_aoi(data["boundary"], cfg)

# Clipped Layers
roads_aoi = data["roads"].copy()

green_aoi = clip_and_add_id(data["green"], aoi_geom, "green_id")
bldg_aoi  = clip_and_add_id(data["buildings"], aoi_geom, "bldg_id")
pop_aoi   = clip_and_add_id(data["pop"], aoi_geom, "pop_id")
neigh_aoi = clip_and_add_id(data["neigh"], aoi_geom, "neigh_id")


# %% [markdown]
# ##### **3. GREEN SPACES HIERARCHY**

# %% [markdown]
#  ***3.1 GREEN SPACES HIERARCHY***

# %%
# 1) Greenspaces hierarchy definitions
class GreenspaceClass(Enum):
    PARK = "park"
    FOREST = "forest"

# Higher rank = higher priority in analyses
HIERARCHY_RANK = {
    GreenspaceClass.PARK: 2,
    GreenspaceClass.FOREST: 1,
}

# Movement/friction cost (lower is easier to traverse/connect)
# For corridor/connectivity weights
FRICTION_COST = {
    GreenspaceClass.PARK: 1.0,
    GreenspaceClass.FOREST: 1.5,
}

# Max acceptable gap distances for connectivity by class (meters)
CONNECTIVITY_GAP_THRESH_M = {
    GreenspaceClass.PARK: 300,
    GreenspaceClass.FOREST: 200,
}

@dataclass
class GreenspaceFeature:
    fid: int
    name: str
    gclass: GreenspaceClass
    rank: int
    friction: float
    gap_threshold_m: float
    geometry: object   # shapely geometry (Polygon/MultiPolygon)
    area_m2: float

    def is_higher_or_equal_priority_than(self, other: "GreenspaceFeature") -> bool:
        return self.rank >= other.rank

    def connectivity_weight(self) -> float:
        """Lower means easier to connect; use in graph edge weights."""
        return self.friction

    def accessibility_score(self) -> float:
        """
        Simple quality score for accessibility weighting later:
        prioritizes parks > forests > shrubland and considers area.
        """
        base = self.rank * 2           # rank bonus
        size = min(self.area_m2 / 10_000, 10)  # up to +10 for size
        return base + size


# %% [markdown]
# ***3.2 GREENSPACES ISOLATION ANALYSIS***

# %%
#### CONNECTIVITY GAP ANALYSIS FOR GREEN SPACES USING KDTREE (fixed + no redundant input calls)

# ---------------- CONFIG ----------------
# (Continuidad) Se asume que `cfg`, `data`, `aoi_geom` y las capas *_aoi ya fueron creadas arriba.

output_gpkg = Path("outputs") / "greenspace_gap_grid.gpkg"
output_layer = "greenspace_gap_grid"
grid_size = 100  # meters

# ensure output folder exists
output_gpkg.parent.mkdir(parents=True, exist_ok=True)

# ---------------- STEP 1: Prepare AOI and Greenspaces (from pipeline, no read_file) ----------------
AOI = gpd.GeoDataFrame({"id": [1]}, geometry=[aoi_geom], crs=f"EPSG:{cfg.crs_epsg}")
greenspaces = clip_and_add_id(data["green"], aoi_geom, "green_id")
greenspaces = greenspaces[greenspaces.geometry.notna() & ~greenspaces.geometry.is_empty].copy()

if greenspaces.empty:
    raise ValueError("No greenspaces found inside AOI after clipping.")

aoi_geom_union = AOI.geometry.iloc[0]

# ---------------- STEP 2: Build KDTree from greenspace centroids ----------------
greenspace_points = np.array(
    [(geom.centroid.x, geom.centroid.y) for geom in greenspaces.geometry],
    dtype=float
)
if len(greenspace_points) == 0:
    raise ValueError("No greenspace centroids to build KDTree.")

tree = cKDTree(greenspace_points)

# ---------------- SIMPLE TEST: KDTree Connectivity (fixed) ----------------
distance, index = tree.query(greenspace_points[0], k=1)
if distance > 1e-6 or index != 0:
    print(f"Quick test warning: distance={distance}, index={index}")
else:
    print("Quick test passed: KDTree works")

# ---------------- STEP 3: Generate regular grid over AOI ----------------
minx, miny, maxx, maxy = AOI.total_bounds
x_coords = np.arange(minx, maxx, grid_size)
y_coords = np.arange(miny, maxy, grid_size)

grid_polygons = []
grid_centroids = []

for x in x_coords:
    for y in y_coords:
        cell = Polygon([
            (x, y),
            (x + grid_size, y),
            (x + grid_size, y + grid_size),
            (x, y + grid_size)
        ])
        if cell.intersects(aoi_geom_union):
            grid_polygons.append(cell)
            c = cell.centroid
            grid_centroids.append((c.x, c.y))

if len(grid_centroids) == 0:
    raise ValueError("No grid cells generated. Check AOI or grid_size.")

grid_centroids = np.asarray(grid_centroids, dtype=float)

# ---------------- STEP 4: Compute nearest greenspace distance ----------------
distances, indices = tree.query(grid_centroids, k=1)
distances = np.asarray(distances, dtype=float)
indices = np.asarray(indices, dtype=int)

# ---------------- STEP 5: Create GeoDataFrame for grid ----------------
veg_col = "Vegetation"
nearest_class = (
    greenspaces.iloc[indices][veg_col].values
    if veg_col in greenspaces.columns
    else np.array(["unknown"] * len(indices), dtype=object)
)

grid_gdf = gpd.GeoDataFrame(
    {
        "dist_to_greenspace_m": distances,
        "nearest_gclass": nearest_class
    },
    geometry=grid_polygons,
    crs=AOI.crs
)

# Flag cells far from greenspaces (>300m)
grid_gdf["far_from_greenspace"] = (grid_gdf["dist_to_greenspace_m"] > 300).astype(int)

# ---------------- STEP 6: Save to GeoPackage ----------------
grid_gdf.to_file(output_gpkg, layer=output_layer, driver="GPKG")

print(f"Analysis complete. Centro district area: {AOI.area.sum():.0f} m²")
print(f"Number of grid cells: {len(grid_gdf)}")
print(f"Saved: {output_gpkg} (layer={output_layer})")

# %% [markdown]
# ***3.3 GREENSPACES AND THEIR ISOLATION INTERACTIVE MAP***

# %%
#### Interactive map showing the Connectivity gap and greenspaces (FIXED)

import warnings
import folium
from branca.element import MacroElement, Template
from IPython.display import display

import geopandas as gpd
import pandas as pd
import numpy as np
from pathlib import Path

# mapclassify is optional; provide a fallback
try:
    import mapclassify as mc
    HAS_MAPCLASSIFY = True
except Exception:
    HAS_MAPCLASSIFY = False
    warnings.warn("mapclassify not available — using numpy quantiles as fallback.")

# --- Inputs: accept either green_AOI OR greenspaces variable names ---

if "grid_gdf" not in globals():
    raise NameError("Required variable 'grid_gdf' not found. Run the gap analysis cell first.")

if "AOI" not in globals():
    raise NameError("Required variable 'AOI' not found. Run the input/AOI preparation first.")

if "green_AOI" in globals():
    greens_src = green_AOI
elif "greenspaces" in globals():
    greens_src = greenspaces
elif "greens" in globals():
    greens_src = greens
else:
    raise NameError("Required greenspaces variable not found (expected 'green_AOI' or 'greenspaces' or 'greens').")

# Copy to local names
grid_gdf_local = grid_gdf.copy()
greens_local = greens_src.copy()
aoi_local = AOI.copy()

# --- Reproject to WGS84 for Leaflet/Folium ---
def ensure_wgs84(gdf: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    if gdf.crs is None:
        raise ValueError("GeoDataFrame has no CRS defined; cannot reproject to EPSG:4326.")
    try:
        epsg = gdf.crs.to_epsg()
    except Exception:
        epsg = None
    return gdf if epsg == 4326 else gdf.to_crs(epsg=4326)

grid_gdf_local = ensure_wgs84(grid_gdf_local)
greens_local = ensure_wgs84(greens_local)
aoi_local = ensure_wgs84(aoi_local)

# --- Prepare classification bins for choropleth ---
dist_col = "dist_to_greenspace_m"
if dist_col not in grid_gdf_local.columns:
    raise KeyError(f"'{dist_col}' column not found in grid_gdf. Run the gap analysis first.")

vals = pd.to_numeric(grid_gdf_local[dist_col], errors="coerce").dropna()
if vals.empty:
    raise ValueError(f"No valid numeric values in '{dist_col}' to classify/plot")

K = 5
if HAS_MAPCLASSIFY:
    scheme = mc.Quantiles(vals, k=K)
    bins = list(map(float, scheme.bins))
else:
    probs = np.linspace(0, 1, num=K + 1)[1:]
    bins = list(np.unique(np.quantile(vals.to_numpy(), probs)))
    bins = [float(b) for b in bins]
    if len(bins) == 0:
        raise ValueError("Unable to compute bins for choropleth")

# --- Build base map using GeoPandas .explore (Folium backend) ---
tooltip_cols = [c for c in [dist_col, "nearest_gclass", "far_from_greenspace"] if c in grid_gdf_local.columns]

# Create base map
m = grid_gdf_local.explore(
    column=dist_col,
    scheme="UserDefined",
    classification_kwds={"bins": bins},
    cmap="YlGnBu",
    legend=True,
    tooltip=tooltip_cols if tooltip_cols else True,
    style_kwds={"fillOpacity": 0.65, "weight": 0},
    tiles="OpenStreetMap",
    name="Connectivity gap grid",
)

# --- Greenspaces overlay ---
if not greens_local.empty:
    greens_local.explore(
        m=m,
        name="Greenspaces",
        style_kwds={"color": "#2ca02c", "weight": 1.5, "fillOpacity": 0.20},
        tooltip=True,
    )

# --- AOI boundary overlay ---
try:
    aoi_boundary = aoi_local.boundary
except Exception:
    aoi_boundary = aoi_local

aoi_boundary.explore(
    m=m,
    name="AOI Boundary",
    style_kwds={"color": "black", "weight": 2, "fillOpacity": 0},
)

# --- Optional: highlight cells farther than 300m ---
flag_col = "far_from_greenspace"
if flag_col in grid_gdf_local.columns:
    far_cells = grid_gdf_local.loc[grid_gdf_local[flag_col] == 1]
    if not far_cells.empty:
        far_cells.explore(
            m=m,
            name="Cells > 300 m",
            style_kwds={"color": "#d62728", "weight": 1.5, "fillOpacity": 0},
            tooltip=[dist_col] if dist_col in far_cells.columns else True,
        )

# --- Layer control ---
folium.LayerControl(collapsed=False).add_to(m)

# ---------------- TITLE & FRAME CONFIG ----------------
MAP_TITLE    = "Greenspace Connectivity Gap Map"
TITLE_BG     = "rgba(255,255,255,0.85)"
TITLE_TXT    = "#333333"
FRAME_COLOR  = "#333333"
FRAME_WIDTH  = "3px"
FRAME_RADIUS = "8px"

# ---------------- INJECT TITLE & FRAME ----------------
title_frame_template = Template(f"""
{{% macro html(this, kwargs) %}}
<style>
  .folium-map {{
    border: {FRAME_WIDTH} solid {FRAME_COLOR};
    border-radius: {FRAME_RADIUS};
    box-shadow: 0 2px 10px rgba(0,0,0,0.2);
  }}
  .map-title {{
    position: fixed;
    top: 10px;
    left: 50%;
    transform: translateX(-50%);
    z-index: 9999;
    background: {TITLE_BG};
    color: {TITLE_TXT};
    padding: 8px 14px;
    border: 1px solid #aaa;
    border-radius: 6px;
    font-family: Arial, Helvetica, sans-serif;
    font-size: 16px;
    line-height: 1.2;
    text-align: center;
    white-space: nowrap;
  }}
  .leaflet-control-layers {{
    z-index: 9999;
  }}
</style>
<div class="map-title">{MAP_TITLE}</div>
{{% endmacro %}}
""")

macro = MacroElement()
macro._template = title_frame_template
m.get_root().add_child(macro)

# --- Display and Save ---
out_html = Path("outputs") / "greenspace_gap_map.html"
out_html.parent.mkdir(parents=True, exist_ok=True)

display(m)
m.save(str(out_html))
print(f"Interactive map saved: {out_html}")


# %% [markdown]
# ##### **4. URBAN HEAT ISLAND**

# %% [markdown]
# ***4.1 URBAN HEAT ISLAND CALCULATION***

# %%
#### UHI CALCULATION (AUTO-CONTAINED & ROBUST)

# Shapely validity handling
try:
    from shapely.validation import make_valid
    HAS_MAKE_VALID = True
except Exception:
    HAS_MAKE_VALID = False


# =============================================================================
# 1. INPUT DATA (USING REFERENCE PIPELINE)
# =============================================================================

try:
    buildings_AOI
except NameError:
    print("buildings_AOI not found — creating it using reference Config pipeline")


    buildings_AOI = clip_and_add_id(
        data["buildings"], aoi_geom, "building_id"
    )

INPUT_VECTOR = buildings_AOI


# =============================================================================
# 2. OUTPUT CONFIG
# (Continuidad) Se asume que `cfg`, `data`, `aoi_geom` y las capas *_aoi ya fueron creadas arriba.
# =============================================================================

OUTPUT_GPKG = Path("outputs") / "uhi_buildings.gpkg"
OUTPUT_LAYER = "uhi_buildings"
OUTPUT_GPKG.parent.mkdir(parents=True, exist_ok=True)

TARGET_EPSG = 25830


# =============================================================================
# 3. PARAMETERS
# =============================================================================

CONST_USAGE_WEIGHT = {
    "patrimonio": 1.0,
    "regular": 1.5,
    "other": 1.0
}


# =============================================================================
# 4. HELPER FUNCTIONS
# =============================================================================

def normalize_usage(val: Optional[str]) -> str:
    if val is None:
        return "other"
    t = str(val).lower()
    if "patrimonio" in t or "historic" in t:
        return "patrimonio"
    if "regular" in t:
        return "regular"
    return "other"


def compute_uhi(area_m2: float, height_m: float, btype: str) -> Optional[float]:
    if area_m2 is None or height_m is None:
        return None
    w = CONST_USAGE_WEIGHT.get(normalize_usage(btype), 1.0)
    return round(w * (0.6 * height_m + 0.4 * area_m2), 2)


def fix_geometries(gdf: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    gdf = gdf.copy()

    def _fix(g):
        if g is None or g.is_empty:
            return None
        if not g.is_valid:
            if HAS_MAKE_VALID:
                return make_valid(g)
            return g.buffer(0)
        return g

    gdf["geometry"] = gdf.geometry.apply(_fix)
    return gdf[gdf.geometry.notna() & ~gdf.geometry.is_empty]


def ensure_crs(gdf: gpd.GeoDataFrame, epsg: int) -> gpd.GeoDataFrame:
    if gdf.crs.to_epsg() != epsg:
        return gdf.to_crs(epsg=epsg)
    return gdf


def estimate_height(area: float) -> float:
    if area < 50: return 3
    if area < 100: return 6
    if area < 500: return 9
    if area < 1000: return 12
    if area < 5000: return 15
    return 20


# =============================================================================
# 5. MAIN UHI PIPELINE
# =============================================================================

gdf = INPUT_VECTOR.copy()
gdf = fix_geometries(gdf)
gdf = ensure_crs(gdf, TARGET_EPSG)

gdf["area_m2"] = gdf.geometry.area

# Building type
if "building_t" in gdf.columns:
    gdf["building_type"] = gdf["building_t"].astype(str)
elif "PROTECCION" in gdf.columns:
    gdf["building_type"] = gdf["PROTECCION"].astype(str)
else:
    gdf["building_type"] = "regular"

# Height
if "ALTURA" in gdf.columns:
    gdf["ALTURA"] = pd.to_numeric(gdf["ALTURA"], errors="coerce")
    gdf["height_m"] = gdf["ALTURA"].fillna(
        gdf["area_m2"].apply(estimate_height)
    )
else:
    gdf["height_m"] = gdf["area_m2"].apply(estimate_height)

# UHI score
gdf["uhi_risk"] = gdf.apply(
    lambda r: compute_uhi(r.area_m2, r.height_m, r.building_type),
    axis=1
)

# =============================================================================
# 6. EXPORT
# =============================================================================

out_cols = [
    c for c in ["building_type", "area_m2", "height_m", "uhi_risk"]
    if c in gdf.columns
] + ["geometry"]

out_gdf = gdf[out_cols].copy()
out_gdf.to_file(OUTPUT_GPKG, layer=OUTPUT_LAYER, driver="GPKG")

print(f" UHI buildings saved: {OUTPUT_GPKG}")
print(f" Features: {len(out_gdf)}")



# %% [markdown]
# ***4.2 UHI DATA PROCESSING***

# %%
### UHI DATA CLEAN UP FOR CHLOROPLETH MAP (FIXED: no hardcoded paths, safe AOI, safe writes, robust overlay)

# ----------------------- CONFIG -----------------------
INPUT_GPKG   = Path("outputs") / "uhi_buildings.gpkg"
INPUT_LAYER  = "uhi_buildings"

OUTPUT_GPKG  = Path("outputs") / "uhi_surface_grid.gpkg"
OUTPUT_LAYER = "uhi_surface_100m_clipped"

GRID_SIZE_M  = 100
K_NEIGHBORS  = 8
IDW_POWER    = 2.0

# ---------------------- REQUIRE AOI ----------------------
if "AOI" not in globals():
    raise NameError(
        "AOI not found. Create AOI using your reference pipeline, e.g.\n"
        "cfg = Config(); data = load_inputs(cfg); aoi_geom = build_aoi(data['boundary'], cfg)\n"
        "AOI = gpd.GeoDataFrame({'id':[1]}, geometry=[aoi_geom], crs=f'EPSG:{cfg.crs_epsg}')"
    )

# ---------------------- PREP CRS ----------------------
# Use AOI CRS if projected; otherwise EPSG:25830
if AOI.crs is not None and getattr(AOI.crs, "is_projected", False):
    target_crs = AOI.crs
else:
    target_crs = gpd.CRS.from_epsg(25830)

aoi = AOI.copy()
if aoi.crs != target_crs:
    aoi = aoi.to_crs(target_crs)

# Dissolve AOI to single polygon for clean clipping
aoi_union = aoi.geometry.unary_union
aoi_gdf = gpd.GeoDataFrame({"id": [1]}, geometry=[aoi_union], crs=target_crs)

# ---------------------- LOAD BUILDINGS ----------------------
if not INPUT_GPKG.exists():
    raise FileNotFoundError(f"Missing input GeoPackage: {INPUT_GPKG}")

b = gpd.read_file(INPUT_GPKG, layer=INPUT_LAYER)

if b.crs is None:
    raise ValueError("Input buildings layer has no CRS. Recreate it with a valid CRS.")
if b.crs != target_crs:
    b = b.to_crs(target_crs)

if "uhi_risk" not in b.columns:
    raise ValueError("Input layer must contain 'uhi_risk'")

b = b[b.geometry.notna() & ~b.geometry.is_empty].copy()
b = b[b.intersects(aoi_union)].copy()

# Coerce uhi to numeric and keep valid
b["uhi_risk"] = gpd.pd.to_numeric(b["uhi_risk"], errors="coerce")
b = b[b["uhi_risk"].notna()].copy()

if b.empty:
    raise ValueError("No buildings with valid 'uhi_risk' inside AOI.")

# ---------------------- BUILD GRID FROM AOI ----------------------
minx, miny, maxx, maxy = aoi_gdf.total_bounds

# Align bounds to grid for clean edges
minx = np.floor(minx / GRID_SIZE_M) * GRID_SIZE_M
miny = np.floor(miny / GRID_SIZE_M) * GRID_SIZE_M
maxx = np.ceil(maxx / GRID_SIZE_M) * GRID_SIZE_M
maxy = np.ceil(maxy / GRID_SIZE_M) * GRID_SIZE_M

x_coords = np.arange(minx, maxx, GRID_SIZE_M)
y_coords = np.arange(miny, maxy, GRID_SIZE_M)

grid_polys = [
    Polygon([(x, y), (x + GRID_SIZE_M, y), (x + GRID_SIZE_M, y + GRID_SIZE_M), (x, y + GRID_SIZE_M)])
    for x in x_coords
    for y in y_coords
]

grid = gpd.GeoDataFrame(
    {"rowid": np.arange(len(grid_polys), dtype=int)},
    geometry=grid_polys,
    crs=target_crs
)

# Clip grid to AOI (overlay can fail in some environments; fallback to clip)
try:
    grid = gpd.overlay(grid, aoi_gdf, how="intersection")
except Exception:
    grid = gpd.clip(grid, aoi_union).copy()

grid = grid[grid.geometry.notna() & ~grid.geometry.is_empty].copy()
if grid.empty:
    raise ValueError("Grid became empty after clipping to AOI. Check AOI geometry / CRS.")

# Interpolation points: centroids of clipped cells
centroids = grid.geometry.centroid
centers = np.column_stack([centroids.x.to_numpy(), centroids.y.to_numpy()])

# ---------------------- IDW INTERPOLATION ----------------------
b_cent = b.geometry.centroid
src_pts  = np.column_stack([b_cent.x.to_numpy(), b_cent.y.to_numpy()])
src_vals = b["uhi_risk"].to_numpy(dtype=float)

uhi_idw = np.zeros(len(grid), dtype=float)

try:
    from scipy.spatial import cKDTree
    tree = cKDTree(src_pts)

    k = min(K_NEIGHBORS, len(src_pts))
    dists, idxs = tree.query(centers, k=k)

    # normalize shapes for k=1
    if dists.ndim == 1:
        dists = dists[:, None]
        idxs = idxs[:, None]

    eps = 1e-9
    weights = 1.0 / np.power(dists + eps, IDW_POWER)
    vals_neigh = src_vals[idxs]
    uhi_idw = (weights * vals_neigh).sum(axis=1) / weights.sum(axis=1)

except Exception:
    # Nearest-neighbor fallback
    x_src, y_src = src_pts[:, 0], src_pts[:, 1]
    for i, (cx, cy) in enumerate(centers):
        d2 = (x_src - cx) ** 2 + (y_src - cy) ** 2
        j = int(np.argmin(d2))
        uhi_idw[i] = float(src_vals[j])

grid["uhi_idw"] = uhi_idw

# ---------------------- SAVE ONE LAYER ONLY ----------------------
OUTPUT_GPKG.parent.mkdir(parents=True, exist_ok=True)

# Delete existing file so you truly keep ONE layer
if OUTPUT_GPKG.exists():
    OUTPUT_GPKG.unlink()

grid.to_file(OUTPUT_GPKG, layer=OUTPUT_LAYER, driver="GPKG")

print(f"UHI surface saved (single layer): {OUTPUT_GPKG} | layer='{OUTPUT_LAYER}'")
print(f"Cells: {len(grid)} | Grid: {GRID_SIZE_M} m | k={K_NEIGHBORS} | power={IDW_POWER}")


# %% [markdown]
# ***4.3 ACCESSIBILITY ANALYSIS***

# %%
### ACCESSIBILITY ANALYSIS (FIXED: no hardcoded paths, no redundant reads, correct CRS handling, bug fixes)

# ---- Parameters ----
# (Continuidad) Se asume que `cfg`, `data`, `aoi_geom` y las capas *_aoi ya fueron creadas arriba.
CRS_METRIC = 25830
WALK_SPEED_MPS = 1.2
THRESHOLD_MIN = 5
ENTRANCE_SPACING_M = 25
POP_FIELD = "VALUE"   # must exist in population layer


# =============================================================================
# 1) INPUTS (use your reference pipeline ONLY)
# =============================================================================

# Clip datasets to AOI
greens = clip_and_add_id(data["green"], aoi_geom, "green_id")
streets = clip_and_add_id(data["roads"], aoi_geom, "edge_id")
pop = clip_and_add_id(data["pop"], aoi_geom, "pop_id")
bldg = clip_and_add_id(data["buildings"], aoi_geom, "building_id")

# AOI GeoDataFrame (for saving / sanity)
AOI = gpd.GeoDataFrame({"id": [1]}, geometry=[aoi_geom], crs=greens.crs)

# Ensure CRS everywhere (DO NOT use inplace=True with to_crs)
def ensure_epsg(gdf: gpd.GeoDataFrame, epsg: int) -> gpd.GeoDataFrame:
    if gdf.crs is None:
        raise ValueError("A GeoDataFrame has no CRS defined.")
    return gdf if gdf.crs.to_epsg() == epsg else gdf.to_crs(epsg=epsg)

greens = ensure_epsg(greens, CRS_METRIC)
streets = ensure_epsg(streets, CRS_METRIC)
pop = ensure_epsg(pop, CRS_METRIC)
bldg = ensure_epsg(bldg, CRS_METRIC)
AOI = ensure_epsg(AOI, CRS_METRIC)

# Basic sanity
if not streets.geom_type.isin(["LineString", "MultiLineString"]).any():
    raise ValueError("Streets must be LineString/MultiLineString geometries.")
if not greens.geom_type.isin(["Polygon", "MultiPolygon"]).any():
    raise ValueError("Greenspaces must be Polygon/MultiPolygon geometries.")
if POP_FIELD not in pop.columns:
    raise ValueError(f"Missing population field '{POP_FIELD}' in population layer.")

print("  Inputs ready:")
print(f"   - Streets: {len(streets)}")
print(f"   - Greenspaces: {len(greens)}")
print(f"   - Population: {len(pop)} (field='{POP_FIELD}')")
print(f"   - Buildings: {len(bldg)}")
print(f"   - CRS: EPSG:{CRS_METRIC}")

# =============================================================================
# 2) KDTree utilities
# =============================================================================
def build_kdtree(nodes_gdf: gpd.GeoDataFrame) -> cKDTree:
    coords = nodes_gdf[["x", "y"]].to_numpy()
    return cKDTree(coords)

def nearest_ids_kdtree(kdtree: cKDTree, nodes_gdf: gpd.GeoDataFrame, query_points):
    q = np.array([(pt.x, pt.y) for pt in query_points])
    _, idxs = kdtree.query(q, k=1)
    return [int(nodes_gdf.iloc[i]["nid"]) for i in idxs]

# =============================================================================
# 3) Build street graph + nodes
# =============================================================================
class StreetGraph:
    def __init__(self, streets_gdf: gpd.GeoDataFrame):
        self.streets_gdf = streets_gdf
        self.G = None
        self.nodes_gdf = None

    @staticmethod
    def _round_xy(x, y, n=3):
        return (round(float(x), n), round(float(y), n))

    def build(self):
        G = nx.Graph()
        node_id_by_xy = {}
        next_id = 0

        def get_node_id(xy):
            nonlocal next_id
            if xy not in node_id_by_xy:
                node_id_by_xy[xy] = next_id
                G.add_node(next_id, x=xy[0], y=xy[1])
                next_id += 1
            return node_id_by_xy[xy]

        for geom in self.streets_gdf.geometry:
            if geom is None or geom.is_empty:
                continue
            lines = [geom] if geom.geom_type == "LineString" else list(geom.geoms)
            for line in lines:
                coords = list(line.coords)
                for i in range(len(coords) - 1):
                    xy1 = self._round_xy(*coords[i])
                    xy2 = self._round_xy(*coords[i + 1])
                    u = get_node_id(xy1)
                    v = get_node_id(xy2)
                    seg_len = Point(xy1).distance(Point(xy2))
                    if G.has_edge(u, v):
                        if seg_len < G[u][v]["length"]:
                            G[u][v]["length"] = seg_len
                    else:
                        G.add_edge(u, v, length=seg_len)

        nodes = pd.DataFrame(
            [(nid, d["x"], d["y"]) for nid, d in G.nodes(data=True)],
            columns=["nid", "x", "y"]
        )
        nodes_gdf = gpd.GeoDataFrame(
            nodes,
            geometry=gpd.points_from_xy(nodes["x"], nodes["y"]),
            crs=self.streets_gdf.crs
        )

        self.G = G
        self.nodes_gdf = nodes_gdf
        return G, nodes_gdf

# =============================================================================
# 4) Greenspace entrances
# =============================================================================
class GreenspaceEntrances:
    def __init__(self, greens_gdf: gpd.GeoDataFrame, spacing_m: float = 25):
        self.greens = greens_gdf
        self.spacing_m = spacing_m
        self.entrance_gdf = None

    @staticmethod
    def sample_perimeter_points(geom, spacing_m):
        pts = []
        polys = [geom] if geom.geom_type == "Polygon" else list(geom.geoms)
        for poly in polys:
            if not isinstance(poly, Polygon):
                continue
            length = poly.exterior.length
            n = max(int(length // spacing_m), 1)
            for i in range(n):
                d = (i / n) * length
                pts.append(poly.exterior.interpolate(d))
        return pts

    def build(self):
        entrance_points = []
        for g in self.greens.geometry:
            if g is None or g.is_empty:
                continue
            entrance_points.extend(self.sample_perimeter_points(g, self.spacing_m))
        self.entrance_gdf = gpd.GeoDataFrame(geometry=entrance_points, crs=self.greens.crs)
        return self.entrance_gdf

# =============================================================================
# 5) Origins from population
# =============================================================================
class Origins:
    def __init__(self, pop_gdf: gpd.GeoDataFrame, pop_field: str):
        self.pop_gdf = pop_gdf
        self.pop_field = pop_field
        self.origins = None

    def build_points(self):
        origins = self.pop_gdf.copy()
        if not origins.geom_type.isin(["Point"]).all():
            origins["geometry"] = origins.geometry.centroid
        if self.pop_field not in origins.columns:
            origins[self.pop_field] = 1.0
        self.origins = origins
        return origins

# =============================================================================
# 6) Accessibility engine
# =============================================================================
class AccessibilityEngine:
    def __init__(self, G, nodes_gdf, walk_speed_mps=1.2, threshold_min=10):
        self.G = G
        self.nodes_gdf = nodes_gdf
        self.walk_speed_mps = walk_speed_mps
        self.threshold_min = threshold_min
        self.kdtree = None

    def prepare_snapper(self):
        self.kdtree = build_kdtree(self.nodes_gdf)

    def snap_points(self, points_gdf):
        return nearest_ids_kdtree(self.kdtree, self.nodes_gdf, list(points_gdf.geometry))

    def multi_source_times(self, sources_node_ids):
        return nx.multi_source_dijkstra_path_length(
            self.G,
            sources=list(set(sources_node_ids)),
            weight="length"
        )

    def attach_times_to_origins(self, origins_gdf, lengths, pop_field):
        def node_time_minutes(nid):
            d = lengths.get(nid, np.inf)
            return (d / self.walk_speed_mps) / 60.0

        out = origins_gdf.copy()
        out["time_min"] = out["node_id"].map(node_time_minutes)
        out["within_thr"] = out["time_min"] <= self.threshold_min

        total_pop = float(out[pop_field].sum())
        covered_pop = float(out.loc[out["within_thr"], pop_field].sum())
        share = covered_pop / total_pop if total_pop > 0 else np.nan
        return out, {"total_pop": total_pop, "covered_pop": covered_pop, "share": share}

# =============================================================================
# 7) RUN
# =============================================================================
# Build graph
sg = StreetGraph(streets)
G, nodes_gdf = sg.build()

# Entrances
entrance_gdf = GreenspaceEntrances(greens, spacing_m=ENTRANCE_SPACING_M).build()

# Origins
origins_gdf = Origins(pop, pop_field=POP_FIELD).build_points()

# Engine
engine = AccessibilityEngine(G, nodes_gdf, walk_speed_mps=WALK_SPEED_MPS, threshold_min=THRESHOLD_MIN)
engine.prepare_snapper()

entrance_node_ids = engine.snap_points(entrance_gdf)
origin_node_ids = engine.snap_points(origins_gdf)

origins_gdf["node_id"] = origin_node_ids

lengths = engine.multi_source_times(entrance_node_ids)
origins_out, summary = engine.attach_times_to_origins(origins_gdf, lengths, pop_field=POP_FIELD)

print(
    f"Population within {THRESHOLD_MIN} min: "
    f"{summary['covered_pop']:.0f}/{summary['total_pop']:.0f} ({summary['share']:.1%})"
)

# =============================================================================
# 8) SAVE (portable)
# =============================================================================
out_gpkg = Path("outputs") / "aoi_accessibility.gpkg"
out_gpkg.parent.mkdir(parents=True, exist_ok=True)

entrance_gdf.to_file(out_gpkg, layer="entrances", driver="GPKG")
origins_out.to_file(out_gpkg, layer="pop_access", driver="GPKG")

print(f"Saved: {out_gpkg}")

# %% [markdown]
# ***4.4 URBAN HEAT ISLAND RISK AND ACCESSIBILITY MAP***

# %%
### UHI RISK AND ACCESSIBILITY CHOROPLETH (FIXED: portable paths, checks, safe bins/legend)

# mapclassify is optional (we add fallback)
try:
    import mapclassify as mc
    HAS_MC = True
except Exception:
    HAS_MC = False

# ---------------- CONFIG (PORTABLE DEFAULTS) ----------------
# If you want, replace these with your absolute paths, but portable is safer.
GRID_GPKG    = Path("outputs") / "uhi_surface_grid.gpkg"
GRID_LAYER   = "uhi_surface_100m_clipped"
UHI_FIELD    = "uhi_idw"

ACCESS_GPKG  = Path("outputs") / "aoi_accessibility.gpkg"
ACCESS_LAYER = "pop_access"

FIG_PATH     = Path("outputs") / "uhi_choropleth_access.png"

N_CLASSES   = 5
CLASS_MODE  = "naturalbreaks"   # "naturalbreaks"/"jenks" or "quantiles"
CMAP = "YlOrRd"

COLOR_WITHIN = "#2ca02c"; MS_WITHIN = 18
COLOR_OUT    = "#d62728"; MS_OUT    = 18

# ---------------- HELPERS ----------------
def read_layer(gpkg_path: Path, layer: str) -> gpd.GeoDataFrame:
    if not gpkg_path.exists():
        raise FileNotFoundError(f"Missing GeoPackage: {gpkg_path.resolve()}")
    return gpd.read_file(gpkg_path, layer=layer)

def ensure_same_crs(base: gpd.GeoDataFrame, other: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    if other.crs != base.crs:
        return other.to_crs(base.crs)
    return other

def compute_bins(values: np.ndarray, k: int, mode: str):
    v = np.asarray(values, dtype=float)
    v = v[~np.isnan(v)]
    if v.size == 0:
        raise ValueError("No valid numeric values to classify.")

    mode = mode.lower().strip()

    # mapclassify modes (preferred)
    if HAS_MC and mode in ("naturalbreaks", "jenks"):
        scheme = mc.NaturalBreaks(v, k=k)
        bins = list(scheme.bins)
        title = "Natural Breaks (Jenks)"
        return bins, title

    if HAS_MC and mode == "quantiles":
        scheme = mc.Quantiles(v, k=k)
        bins = list(scheme.bins)
        title = "Quantiles"
        return bins, title

    # fallback without mapclassify: quantile bins
    probs = np.linspace(0, 1, num=k + 1)[1:]
    bins = list(np.unique(np.quantile(v, probs)))
    if len(bins) < 2:
        # if too few unique values, create simple linear bins
        bins = list(np.linspace(v.min(), v.max(), num=k + 1)[1:])
    title = "Quantiles (fallback)"
    return bins, title

# ---------------- LOAD GRID ----------------
grid = read_layer(GRID_GPKG, GRID_LAYER)

if UHI_FIELD not in grid.columns:
    raise KeyError(f"Column '{UHI_FIELD}' not found in layer '{GRID_LAYER}'")

# ---------------- LOAD ACCESS POINTS ----------------
try:
    origins = origins_out.copy()  # if produced earlier in notebook
except Exception:
    origins = read_layer(ACCESS_GPKG, ACCESS_LAYER)

# ---------------- HANDLE AOI ----------------
# Prefer AOI variable from your pipeline; otherwise use grid extent
try:
    AOI  # noqa
    aoi_gdf = AOI.copy()
except Exception:
    from shapely.geometry import box
    aoi_poly = box(*grid.total_bounds)
    aoi_gdf = gpd.GeoDataFrame({"id": [1]}, geometry=[aoi_poly], crs=grid.crs)

# ---------------- CRS ALIGNMENT ----------------
aoi_gdf = ensure_same_crs(grid, aoi_gdf)
origins = ensure_same_crs(grid, origins)

# ---------------- VALIDATE ACCESS FIELD ----------------
if "within_thr" not in origins.columns:
    raise ValueError("Accessibility layer must contain 'within_thr' (boolean or 0/1).")

# ---------------- CLASSIFY UHI ----------------
values = gpd.pd.to_numeric(grid[UHI_FIELD], errors="coerce").to_numpy()
bins, title_mode = compute_bins(values, k=N_CLASSES, mode=CLASS_MODE)

# ---------------- SPLIT ACCESS POINTS ----------------
mask_within = origins["within_thr"].astype(bool)
orig_within = origins.loc[mask_within]
orig_out    = origins.loc[~mask_within]

# Labels
try:
    thr = THRESHOLD_MIN
except Exception:
    thr = 5
label_le = f"≤ {thr} min"
label_gt = f"> {thr} min"

# ---------------- PLOT ----------------
FIG_PATH.parent.mkdir(parents=True, exist_ok=True)

fig, ax = plt.subplots(figsize=(11, 11), dpi=220)

# Choropleth
grid.plot(
    column=UHI_FIELD,
    cmap=CMAP,
    scheme="UserDefined",
    classification_kwds={"bins": bins},
    legend=False,
    linewidth=0,
    edgecolor="none",
    ax=ax,
)

# AOI boundary
aoi_gdf.boundary.plot(ax=ax, color="black", linewidth=1.0)

# Accessibility points
if not orig_within.empty:
    orig_within.plot(ax=ax, color=COLOR_WITHIN, markersize=MS_WITHIN, marker="o")
if not orig_out.empty:
    orig_out.plot(ax=ax, color=COLOR_OUT, markersize=MS_OUT, marker="o")

# ---------------- LEGEND ----------------
vals_clean = np.asarray(values, dtype=float)
vals_clean = vals_clean[~np.isnan(vals_clean)]
vmin = float(vals_clean.min())
vmax = float(vals_clean.max())

# Build class edges and colors safely
class_edges = [vmin] + list(bins)
n_classes = len(class_edges) - 1
cmap = plt.get_cmap(CMAP)

uhi_handles = []
for i in range(n_classes):
    # safe normalization: i/(n_classes-1) with guard
    t = i / (n_classes - 1) if n_classes > 1 else 0.5
    color = cmap(t)
    label = f"{class_edges[i]:.2f}–{class_edges[i+1]:.2f}"
    uhi_handles.append(Patch(facecolor=color, edgecolor="none", label=label))

access_handles = [
    Line2D([0], [0], marker="o", color="w", label=label_le,
           markerfacecolor=COLOR_WITHIN, markersize=10),
    Line2D([0], [0], marker="o", color="w", label=label_gt,
           markerfacecolor=COLOR_OUT, markersize=10),
]

combined_handles = (
    [Patch(facecolor="none", edgecolor="none", label=f"UHI (IDW) — {title_mode}")]
    + uhi_handles
    + [Patch(facecolor="none", edgecolor="none", label="Accessibility")]
    + access_handles
)

ax.legend(
    handles=combined_handles,
    loc="upper right",
    fontsize=9,
    frameon=True,
    ncol=1,
    borderaxespad=0.6
)

# ---------------- GRID LINES + TICKS ----------------
minx, miny, maxx, maxy = grid.total_bounds
ax.set_xticks(np.linspace(minx, maxx, num=8))
ax.set_yticks(np.linspace(miny, maxy, num=8))
ax.tick_params(labelsize=9)
ax.grid(True, which="both", linestyle="--", linewidth=0.6, alpha=0.5)
ax.set_aspect("equal")

# ---------------- TITLE + SAVE ----------------
plt.suptitle("MADRID CENTRO UHI SURFACE AND ACCESSIBILITY POINTS", fontsize=13, y=0.98)
plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.savefig(FIG_PATH, dpi=300)
plt.show()

print(f"Map saved to: {FIG_PATH.resolve()}")
print(f"UHI bins: {[round(float(b), 4) for b in bins]}")
print(f"UHI range: {vmin:.4f} – {vmax:.4f}")


# %% [markdown]
# ##### **6. URBAN GREEN SPACES COVERAGE WITHIN 5 MINUTES WALKING DISTANCE**

# %%
def iter_lines(geom) -> Iterable[LineString]:
    if geom is None or geom.is_empty:
        return
    if geom.geom_type == "LineString":
        yield geom
    elif geom.geom_type == "MultiLineString":
        for part in geom.geoms:
            yield part


def roads_to_graph(gdf_roads: gpd.GeoDataFrame) -> nx.Graph:
    """Convert roads lines into an undirected weighted graph (edges weighted by Euclidean length)."""
    G = nx.Graph()
    for geom in gdf_roads.geometry:
        for line in iter_lines(geom) or []:
            coords = list(line.coords)
            for p1, p2 in zip(coords[:-1], coords[1:]):
                u = (float(p1[0]), float(p1[1]))
                v = (float(p2[0]), float(p2[1]))
                w = ((u[0]-v[0])**2 + (u[1]-v[1])**2) ** 0.5
                if G.has_edge(u, v):
                    if w < G[u][v]["weight"]:
                        G[u][v]["weight"] = w
                else:
                    G.add_edge(u, v, weight=w)
    return G


def build_kdtree_from_nodes(G: nx.Graph) -> Tuple[np.ndarray, cKDTree]:
    nodes = np.array(list(G.nodes()), dtype=float)
    return nodes, cKDTree(nodes)


def snap_point_to_node(pt: Point, nodes: np.ndarray, tree: cKDTree) -> Tuple[float, float]:
    _, idx = tree.query([pt.x, pt.y], k=1)
    return tuple(nodes[idx])


def cutoff_meters(cfg: Config) -> int:
    """Walking distance threshold in meters for t_min at walk_speed_kmh."""
    return int(round(cfg.t_min * (cfg.walk_speed_kmh * 1000 / 60)))


def compute_existing_coverage(
    cfg: Config,
    G: nx.Graph,
    nodes: np.ndarray,
    tree: cKDTree,
    green_aoi: gpd.GeoDataFrame,
    aoi_geom
):
    """
    Existing coverage: snap green centroids to network, multi-source Dijkstra (cutoff),
    convert reachable nodes to concave hull -> covered, then derive not_covered.
    """
    centroids = green_aoi.geometry.centroid
    snapped_sources = list(set(snap_point_to_node(pt, nodes, tree) for pt in centroids))

    reachable_dist = nx.multi_source_dijkstra_path_length(
        G, sources=snapped_sources, cutoff=cutoff_meters(cfg), weight="weight"
    )
    reachable_nodes = list(reachable_dist.keys())
    pts = MultiPoint([Point(x, y) for (x, y) in reachable_nodes])

    hull = concave_hull(pts, ratio=cfg.hull_ratio, allow_holes=cfg.allow_holes).buffer(0)
    covered = hull.intersection(aoi_geom)
    not_covered = aoi_geom.difference(covered)

    # Stats
    aoi_m2 = aoi_geom.area
    covered_m2 = covered.area
    not_covered_m2 = not_covered.area

    stats = pd.DataFrame([{
        "AOI (m²)": aoi_m2,
        "Covered 5-min (m²)": covered_m2,
        "Not covered (m²)": not_covered_m2,
        "Covered (%)": 100 * covered_m2 / aoi_m2 if aoi_m2 else 0,
        "Not covered (%)": 100 * not_covered_m2 / aoi_m2 if aoi_m2 else 0,
        "Cutoff (m)": cutoff_meters(cfg),
        "Time threshold (min)": cfg.t_min,
        "Walk speed (km/h)": cfg.walk_speed_kmh,
    }])

    return covered, not_covered, stats

# %% [markdown]
# ##### **7. POSSIBLE LOCATIONS FOR NEW URBAN GREEN SPACES**

# %%
def random_points_in_geom(geom, n: int, rng: np.random.Generator, max_factor: int = 1200) -> List[Point]:
    """
    Generate random points inside a given geometry.

    Parameters
    ----------
    geom : shapely geometry
        Polygon or multipolygon within which points are generated.
    n : int
        Number of random points to generate.
    rng : numpy.random.Generator
        Random number generator used for reproducible sampling.
    max_factor : int, optional
        Factor controlling the maximum number of sampling attempts.

    Returns
    -------
    list of shapely.geometry.Point
        Randomly generated points located inside the geometry.
    """

    if geom is None or geom.is_empty or n <= 0:
        return []

    if isinstance(geom, MultiPolygon):
        polys = list(geom.geoms)
        areas = np.array([p.area for p in polys], dtype=float)
        probs = areas / areas.sum()
        chosen = rng.choice(len(polys), size=n, replace=True, p=probs)
        pts: List[Point] = []
        for idx in chosen:
            pts += random_points_in_geom(polys[idx], 1, rng, max_factor=max_factor)
        return pts

    minx, miny, maxx, maxy = geom.bounds
    pts, tries = [], 0
    max_tries = n * max_factor
    while len(pts) < n and tries < max_tries:
        p = Point(rng.uniform(minx, maxx), rng.uniform(miny, maxy))
        if geom.contains(p):
            pts.append(p)
        tries += 1
    return pts


def generate_candidates(cfg: Config, not_covered, neigh_aoi: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    """
    Generate candidate locations within uncovered areas. Two modes:
    - 'random': N candidates inside not_covered
    - 'neighborhood': pts_per_neigh inside (neighborhood ∩ not_covered)

    Parameters
    ----------
    cfg : Config
        Configuration object controlling the candidate generation mode
        and parameters.
    not_covered : shapely geometry
        Polygon representing areas not covered by existing infrastructure.
    neigh_aoi : GeoDataFrame
        Neighborhood polygons within the area of interest.

    Returns
    -------
    GeoDataFrame
        Candidate point locations with neighborhood attribution
        (when using neighborhood mode).
    """
    rng = np.random.default_rng(cfg.seed)

    if cfg.mode == "random":
        pts = random_points_in_geom(not_covered, cfg.n_candidates_random, rng, cfg.max_factor)
        return gpd.GeoDataFrame({"cand_id": range(len(pts))}, geometry=pts, crs=neigh_aoi.crs)

    # neighborhood-based
    ngbh_uncov = neigh_aoi.copy()
    ngbh_uncov["geom_uncov"] = ngbh_uncov.geometry.intersection(not_covered).buffer(0)
    ngbh_uncov = ngbh_uncov[~ngbh_uncov["geom_uncov"].is_empty].copy()

    rows = []
    cid = 0
    for row in ngbh_uncov.itertuples():
        pts = random_points_in_geom(row.geom_uncov, cfg.pts_per_neigh, rng, cfg.max_factor)
        for p in pts:
            rows.append({"cand_id": cid, cfg.neigh_col: getattr(row, cfg.neigh_col), "geometry": p})
            cid += 1

    return gpd.GeoDataFrame(rows, geometry="geometry", crs=neigh_aoi.crs)


def isochrone_poly_edges_convex(
    G: nx.Graph,
    center_node: Tuple[float, float],
    cutoff_m: float,
    tiny_buffer: float = 0.0
):
    """
    Approximate isochrone polygon using convex hull from reachable edges endpoints.

    Parameters
    ----------
    G : networkx.Graph
        Road network graph with edge weights representing distances.
    center_node : tuple of float
        Coordinates of the center node in the network.
    cutoff_m : float
        Maximum travel distance (in meters) for the isochrone.
    tiny_buffer : float, optional
        Small buffer applied to improve polygon robustness.

    Returns
    -------
    shapely geometry or None
        Isochrone polygon representing the reachable area, or None if the
        polygon cannot be created.
    """
    dist = nx.single_source_dijkstra_path_length(G, center_node, cutoff=cutoff_m, weight="weight")
    nodes_reach = set(dist.keys())
    if len(nodes_reach) < 10:
        return None

    edge_pts = []
    for u, v in G.edges():
        if u in nodes_reach and v in nodes_reach:
            edge_pts.append(Point(u[0], u[1]))
            edge_pts.append(Point(v[0], v[1]))

    if len(edge_pts) < 3:
        return None

    poly = MultiPoint(edge_pts).convex_hull
    poly = poly.buffer(tiny_buffer).buffer(0) if (tiny_buffer and tiny_buffer > 0) else poly.buffer(0)
    return None if poly.is_empty else poly


def far_enough_seq(pt: Point, accepted: List[Point], min_dist: float) -> bool:
    """
    Tests if the input point is at least a minimum distance away from all
    accepted points.

    Parameters
    ----------
    pt : shapely.geometry.Point
        Candidate point to be evaluated.
    accepted : list of shapely.geometry.Point
        Points that have already been selected.
    min_dist : float
        Minimum allowed distance between points.

    Returns
    -------
    bool
        True if the point is farther than the minimum distance from all
        accepted points, False otherwise.
    """
    return all(pt.distance(ap) > min_dist for ap in accepted)


def export_gpkg(out_path: str, layers: Dict[str, gpd.GeoDataFrame]) -> str:
    """
    Export multiple GeoDataFrames to GeoPackage layers.

    Parameters
    ----------
    out_path : str
        File path where the GeoPackage will be created.
    layers : dict
        Dictionary mapping layer names to GeoDataFrames.

    Returns
    -------
    str
        Path to the created GeoPackage file.
    """
    for name, gdf in layers.items():
        gdf.to_file(out_path, layer=name, driver="GPKG")
    return out_path

# %% [markdown]
# ***7.1 LOCATION CRITERIA: population coverage***

# %%
def pop_sum_within(pop_gdf: gpd.GeoDataFrame, geom, pop_col: str) -> float:
    """
    Calculates the population inside an area. Returns zero if the area is empty.

    Parameters
    ----------
    pop_gdf : GeoDataFrame
        Population features containing a population attribute.
    geom : shapely geometry
        Polygon or multipolygon defining the area of interest.
    pop_col : str
        Name of the population column to be summed.

    Returns
    -------
    float
        Total population within the geometry.
    """
    if geom is None or geom.is_empty:
        return 0.0
    tmp = gpd.GeoDataFrame([{"id": 1}], geometry=[geom], crs=pop_gdf.crs)
    hit = gpd.sjoin(pop_gdf, tmp, predicate="within", how="inner")
    return float(hit[pop_col].sum())


def score_candidates_by_population(
    cfg: Config,
    G: nx.Graph,
    nodes: np.ndarray,
    tree: cKDTree,
    candidates: gpd.GeoDataFrame,
    pop_uncov: gpd.GeoDataFrame,
    not_covered
):
    """
    Checks each candidate location to see how much new population it would cover.

    Parameters
    ----------
    candidates : GeoDataFrame
        Candidate point locations to be evaluated.
    G : networkx graph
        Road network graph used for isochrone computation.
    nodes : array-like
        Coordinates of network nodes.
    tree : cKDTree
        Spatial index for snapping candidate points to the nearest node.
    pop_uncov : GeoDataFrame
        Population features located in previously uncovered areas.
    not_covered : shapely geometry
        Polygon representing areas not covered before intervention.
    cfg : Config
        Configuration object containing distance thresholds and parameters.

    Returns
    -------
    GeoDataFrame
        Candidate points with marginal population gain scores.
    GeoDataFrame
        Isochrone polygons for each candidate location.
    GeoDataFrame
        Polygons representing newly covered (marginal) areas.
    list
        List of raw isochrone geometries.
    list
        List of raw marginal gain geometries.
    """
    cutoff = cutoff_meters(cfg)

    def eval_one(pt: Point):
        """
        Moves the point to the nearest road, calculates walking reach, and counts
        newly covered population.

        Parameters
        ----------
        pt : shapely.geometry.Point
            Candidate location to be evaluated.

        Returns
        -------
        center : shapely.geometry.Point
        Candidate point snapped to the nearest network node.
        """
        center = snap_point_to_node(pt, nodes, tree)
        poly = isochrone_poly_edges_convex(G, center, cutoff_m=cutoff, tiny_buffer=cfg.tiny_buffer)
        if poly is None:
            return center, None, None, 0.0
        gain = poly.intersection(not_covered)
        score = pop_sum_within(pop_uncov, gain, cfg.pop_col) if (gain and not gain.is_empty) else 0.0
        return center, poly, gain, score

    results = list(map(eval_one, candidates.geometry))
    cand_nodes, polys, gains, scores = zip(*results)

    scored = candidates.copy()
    scored["snapped_xy"] = list(cand_nodes)
    scored["marg_pop"] = np.array(scores, dtype=float)

    cand_iso = gpd.GeoDataFrame(scored.drop(columns="geometry"), geometry=[p if p else Point() for p in polys], crs=scored.crs)
    cand_iso = cand_iso[~cand_iso.geometry.is_empty].copy()

    cand_gain = gpd.GeoDataFrame(scored.drop(columns="geometry"), geometry=[g if g else Point() for g in gains], crs=scored.crs)
    cand_gain = cand_gain[~cand_gain.geometry.is_empty].copy()

    return scored, cand_iso, cand_gain, list(polys), list(gains)


def select_top_k_with_min_dist(cfg: Config, candidates_scored: gpd.GeoDataFrame, score_col: str) -> gpd.GeoDataFrame:
    """
    Selects the best locations while making sure they are not too close to each other.

    Parameters
    ----------
    cfg : Config
        Configuration object containing the number of locations to select and
        the minimum allowed distance between them.
    candidates_scored : GeoDataFrame
        Candidate locations with a scoring attribute.
    score_col : str
        Name of the column used to rank candidates.

    Returns
    -------
    GeoDataFrame
        Selected candidate locations with an assigned rank.
    """

    ranked = candidates_scored.sort_values(score_col, ascending=False)
    selected_idx, accepted_pts = [], []

    for row in ranked.itertuples():
        if getattr(row, score_col) <= 0:
            break
        if not accepted_pts or far_enough_seq(row.geometry, accepted_pts, cfg.min_dist_m):
            selected_idx.append(row.Index)
            accepted_pts.append(row.geometry)
        if len(selected_idx) >= cfg.top_k:
            break

    sel = candidates_scored.loc[selected_idx].copy()
    sel["rank"] = np.arange(1, len(sel) + 1)
    return sel


def population_coverage_summary(cfg: Config, pop_aoi: gpd.GeoDataFrame, covered, not_covered, selected_iso: gpd.GeoDataFrame):
    """
    Calculates total population and shows how coverage changes after new locations
    are added.

    Parameters
    ----------
    cfg : Config
        Configuration object containing the population column name.
    pop_aoi : GeoDataFrame
        Population features within the area of interest.
    covered : shapely geometry
        Polygon representing the area already covered before intervention.
    not_covered : shapely geometry
        Polygon representing the area not covered before intervention.
    selected_iso : GeoDataFrame
        Isochrones of the newly selected candidate locations.

    Returns
    -------
    DataFrame
    """

    pop_total = float(pop_aoi[cfg.pop_col].sum())
    pop_before = pop_sum_within(pop_aoi, covered, cfg.pop_col)

    gain_union = selected_iso.union_all().intersection(not_covered)
    pop_new = pop_sum_within(pop_aoi, gain_union, cfg.pop_col)
    pop_after = pop_before + pop_new

    # how much of uncov population is captured
    pop_uncov_total = pop_sum_within(pop_aoi, not_covered, cfg.pop_col)
    pct_gain_of_uncov = 100 * pop_new / pop_uncov_total if pop_uncov_total else 0

    return pd.DataFrame([{
        "Pop total AOI": pop_total,
        "Pop covered BEFORE": pop_before,
        "Pop newly covered (marginal)": pop_new,
        "Pop covered AFTER": pop_after,
        "Covered BEFORE (%)": 100 * pop_before / pop_total if pop_total else 0,
        "New coverage (%)": 100 * pop_new / pop_total if pop_total else 0,
        "Covered AFTER (%)": 100 * pop_after / pop_total if pop_total else 0,
        "Pop total NOT covered": pop_uncov_total,
        "New coverage of NOT covered (%)": pct_gain_of_uncov,
    }])


# %% [markdown]
# ***7.2 LOCATION CRITERIA: equitable access***

# %%
def equitable_scoring(
    cfg: Config,
    pop_aoi: gpd.GeoDataFrame,
    neigh_aoi: gpd.GeoDataFrame,
    covered
) -> pd.DataFrame:
    """
    Calculates weights for each neighborhood based on how much of its population is already covered.
    Neighborhoods with less coverage are given higher priority.

    Inputs
    ----------
    cfg : Config
        Configuration object containing neighborhood and population column names.
    pop_aoi : GeoDataFrame
        Population features clipped to the area of interest.
    neigh_aoi : GeoDataFrame
        Neighborhood polygons within the area of interest.
    covered : shapely geometry
        Polygon representing the area covered before adding new candidates.

    Returns
    -------
    DataFrame
        Table of equity weights by neighborhood.

    """

    # --- Clean neighborhood GeoDataFrame ---
    neigh = neigh_aoi[[cfg.neigh_col, "geometry"]].copy()
    neigh = gpd.GeoDataFrame(neigh, geometry="geometry", crs=neigh_aoi.crs)

    # -------------------------
    # Total population by neighborhood
    # -------------------------
    pop_neigh = clean_sjoin(gpd.sjoin( pop_aoi, neigh, predicate="within", how="inner"))

    tot = (pop_neigh.groupby(cfg.neigh_col)[cfg.pop_col].sum().rename("pop_total"))

    # -------------------------
    # Population covered BEFORE (baseline)
    # -------------------------
    covered_gdf = gpd.GeoDataFrame([{"id": 1}], geometry=[covered], crs=pop_aoi.crs)

    pop_cov = clean_sjoin(gpd.sjoin(pop_aoi,covered_gdf,predicate="within",how="inner"))

    pop_cov_neigh = clean_sjoin(gpd.sjoin(pop_cov,neigh,predicate="within",how="inner"))

    cov = (pop_cov_neigh.groupby(cfg.neigh_col)[cfg.pop_col].sum().rename("pop_covered_before") )

    # -------------------------
    # Equity weights
    # -------------------------
    df = pd.concat([tot, cov], axis=1).fillna(0)

    df["weight"] = 1.0 / (df["pop_covered_before"] + 1.0)

    return df.reset_index()


def apply_equity_weights(cfg: Config, candidates_scored: gpd.GeoDataFrame, equity_table: pd.DataFrame) -> gpd.GeoDataFrame:
    """
    Calculates a score for each candidate by weighting its population
    impact based on neighborhood equity.

    Inputs
    ----------
    cfg : Config
        Configuration object containing the neighborhood column name.
    candidates_scored : GeoDataFrame
        Candidate locations with marginal population values.
    equity_table : DataFrame
        Table of equity weights by neighborhood.

    Returns
    ----------
    GeoDataFrame
        Candidate locations with an added equity-adjusted score.
    """
    out = candidates_scored.merge(equity_table[[cfg.neigh_col, "weight"]], on=cfg.neigh_col, how="left")
    out["weight"] = out["weight"].fillna(0.0)
    out["equitable_score"] = out["marg_pop"] * out["weight"]
    return out


# %%
if __name__ == "__main__":

    cfg = Config(
        mode="neighborhood",    # "random" or "neighborhood"
        pts_per_neigh=10,
        top_k=2,
        min_dist_m=500,
        out_gpkg="green_candidates_structured.gpkg"
    )

    # --------------------------------------------------------
    # Inputs
    # --------------------------------------------------------

    roads_aoi = clip_and_add_id(data["roads"], aoi_geom, "road_id")
    pop_aoi   = clip_and_add_id(data["pop"], aoi_geom, "pop_id")
    green_aoi = clip_and_add_id(data["green"], aoi_geom, "green_id")
    neigh_aoi = clip_and_add_id(data["neigh"], aoi_geom, "ngb_id")

    # --------------------------------------------------------
    # Network + existing coverage (5 min)
    # --------------------------------------------------------
    G = roads_to_graph(roads_aoi)
    nodes, tree = build_kdtree_from_nodes(G)

    covered, not_covered, area_stats = compute_existing_coverage(
        cfg, G, nodes, tree, green_aoi, aoi_geom
    )

    pop_uncov = pop_aoi[pop_aoi.within(not_covered)].copy()
    if pop_uncov.empty:
        raise ValueError("No population points inside not_covered.")

    # --------------------------------------------------------
    # Proposing new spots (candidates)
    # --------------------------------------------------------
    candidates = generate_candidates(cfg, not_covered, neigh_aoi)
    if candidates.empty:
        raise ValueError("No candidates generated.")

    # --------------------------------------------------------
    # Coverage population
    # --------------------------------------------------------
    cand_scored, cand_iso, cand_gain, cand_polys, cand_gains = score_candidates_by_population(
        cfg, G, nodes, tree, candidates, pop_uncov, not_covered
    )

    selected_pop = select_top_k_with_min_dist(
        cfg, cand_scored, score_col="marg_pop"
    )

    idx_pop = list(selected_pop.index)
    selected_pop_iso = gpd.GeoDataFrame(
        {"rank": selected_pop["rank"], "marg_pop": selected_pop["marg_pop"]},
        geometry=[cand_polys[i] for i in idx_pop],
        crs=candidates.crs
    )

    selected_pop_gain = gpd.GeoDataFrame(
        {"rank": selected_pop["rank"], "marg_pop": selected_pop["marg_pop"]},
        geometry=[cand_gains[i] for i in idx_pop],
        crs=candidates.crs
    )

    pop_summary = population_coverage_summary(
        cfg, pop_aoi, covered, not_covered, selected_pop_iso
    )

    # --------------------------------------------------------
    # Remove leftover columns from spatial join
    # --------------------------------------------------------
    cand_scored = clean_sjoin(cand_scored)

    # --------------------------------------------------------
    # 4.2) Equitable access (coverage-based equity)
    # --------------------------------------------------------
    equity_table = equitable_scoring(cfg, pop_aoi, neigh_aoi, covered)

    cand_equity = apply_equity_weights(
        cfg, cand_scored, equity_table
    )

    selected_equity = select_top_k_with_min_dist(
        cfg, cand_equity, score_col="equitable_score"
    )

    idx_eq = list(selected_equity.index)
    selected_equity_iso = gpd.GeoDataFrame(
        {
            "rank": selected_equity["rank"],
            "equitable_score": selected_equity["equitable_score"]
        },
        geometry=[cand_polys[i] for i in idx_eq],
        crs=candidates.crs
    )

    selected_equity_gain = gpd.GeoDataFrame(
        {
            "rank": selected_equity["rank"],
            "equitable_score": selected_equity["equitable_score"]
        },
        geometry=[cand_gains[i] for i in idx_eq],
        crs=candidates.crs
    )

    # --------------------------------------------------------
    # Export – BOTH approaches in the same GeoPackage
    # --------------------------------------------------------
    out_path = export_gpkg(cfg.out_gpkg, {

        # Section 3
        "covered_existing": gpd.GeoDataFrame(geometry=[covered], crs=roads_aoi.crs),
        "not_covered_initial": gpd.GeoDataFrame(geometry=[not_covered], crs=roads_aoi.crs),

        # Candidates
        "candidates_points": cand_scored,
        "candidates_isochrones": cand_iso,
        "candidates_gain": cand_gain,

        # 4.1 Population-based
        "selected_points_population": selected_pop,
        "selected_isochrones_population": selected_pop_iso,
        "selected_gain_population": selected_pop_gain,

        # 4.2 Equity-based
        "selected_points_equity": selected_equity,
        "selected_isochrones_equity": selected_equity_iso,
        "selected_gain_equity": selected_equity_gain,
    })

    # --------------------------------------------------------
    # Console outputs (for report)
    # --------------------------------------------------------
    print("=== 3) Area coverage stats ===")
    print(area_stats)

    print("\n=== 4.1) Population coverage summary ===")
    print(pop_summary)

    print("\n=== 4.2) Equity weights by neighborhood ===")
    print(equity_table.sort_values("weight", ascending=False).head(10))

    print("\nSaved:", out_path)

# %%

#Population sum within polygon (spatial join–based)
if __name__ == "__main__":
    def pop_sum_within(pop_gdf, geom, pop_col):
        """Compute the sum of a population attribute for features contained
        within a polygon.

        Inputs
        ----------
        pop_gdf : GeoDataFrame
            Population features with a population attribute.
        geom : shapely geometry
            Polygon or multipolygon defining the area of interest.
        pop_col : str
            Name of the population column to be summed.

        Output:
        ----------
            Total population within the geometry (float).
        """
        if geom is None or geom.is_empty:
            return 0.0
        tmp = gpd.GeoDataFrame([{"id": 1}], geometry=[geom], crs=pop_gdf.crs)
        hit = gpd.sjoin(pop_gdf, tmp, predicate="within", how="inner")
        return float(hit[pop_col].sum())

    if __name__ == "__main__":
        # Population sums before/after coverage
        pop_total_aoi = float(pop_aoi[cfg.pop_col].sum())
        pop_covered_before = pop_sum_within(pop_aoi, covered, cfg.pop_col)
        pop_uncov_total = pop_sum_within(pop_aoi, not_covered, cfg.pop_col)


        # Population-based results
        gain_pop = selected_pop_iso.union_all().intersection(not_covered)

    pop_new_pop = pop_sum_within(pop_aoi, gain_pop, cfg.pop_col)
    pop_after_pop = pop_covered_before + pop_new_pop


    # Equity-based results
    gain_equity = selected_equity_iso.union_all().intersection(not_covered)

    pop_new_equity = pop_sum_within(pop_aoi, gain_equity, cfg.pop_col)
    pop_after_equity = pop_covered_before + pop_new_equity


    # Comparative table
    comparison = pd.DataFrame([
        {
            "Approach": "4.1 Population-based",
            "Selected points": len(selected_pop),
            "Population covered BEFORE": pop_covered_before,
            "New population covered": pop_new_pop,
            "Population covered AFTER": pop_after_pop,
            "New coverage (% AOI)": 100 * pop_new_pop / pop_total_aoi if pop_total_aoi else 0,
            "New coverage (% not covered)": 100 * pop_new_pop / pop_uncov_total if pop_uncov_total else 0,
        },
        {
            "Approach": "4.2 Equity-based",
            "Selected points": len(selected_equity),
            "Population covered BEFORE": pop_covered_before,
            "New population covered": pop_new_equity,
            "Population covered AFTER": pop_after_equity,
            "New coverage (% AOI)": 100 * pop_new_equity / pop_total_aoi if pop_total_aoi else 0,
            "New coverage (% not covered)": 100 * pop_new_equity / pop_uncov_total if pop_uncov_total else 0,
        }
    ])

    comparison

    # %% [markdown]
    # ##### **8. VISUALIZATION**

    # %% [markdown]
    # * **Input data in the Area of Interest: Center, Madrid**

    # %%
    # Buildings from AOI
    bldg_aoi = clip_and_add_id(data["buildings"], aoi_geom, "bldg_id")

    # Overall CRS for plotting
    crs_m = roads_aoi.crs
    roads_m = roads_aoi.to_crs(crs_m)
    green_m = green_aoi.to_crs(crs_m)
    neigh_m = neigh_aoi.to_crs(crs_m)
    bldg_m  = bldg_aoi.to_crs(crs_m) if (bldg_aoi is not None and not bldg_aoi.empty) else None
    aoi_m   = gpd.GeoDataFrame(geometry=[aoi_geom], crs=crs_m)

    # Plot setup + layers
    fig, ax = plt.subplots(figsize=(12, 10), dpi=200)

    neigh_m.plot(ax=ax, facecolor="none", edgecolor="#666666", linewidth=0.8)
    green_m.plot(ax=ax, facecolor="green", edgecolor="green", alpha=0.35, linewidth=0.6)

    if bldg_m is not None:
        bldg_m.plot(ax=ax, facecolor="#999999", edgecolor="#666666", alpha=0.25, linewidth=0.3)

    aoi_m.boundary.plot(ax=ax, color="black", linewidth=2.5)


    ax.set_aspect("equal")
    ax.set_title("Centro (AOI): Neighborhoods, Vegetation and Buildings", fontsize=14)

    # Coordinates and ticks
    ax.set_xlabel(f"X coordinate ({crs_m.to_string()})")
    ax.set_ylabel(f"Y coordinate ({crs_m.to_string()})")

    ax.xaxis.set_major_formatter(ScalarFormatter(useMathText=False))
    ax.yaxis.set_major_formatter(ScalarFormatter(useMathText=False))
    ax.tick_params(axis="both", labelsize=9)

    legend_items = [
        mpatches.Patch(facecolor="green", edgecolor="green", alpha=0.35, label="Vegetation"),
        mpatches.Patch(facecolor="#999999", edgecolor="#666666", alpha=0.25, label="Buildings") if bldg_m is not None else None,
        Line2D([0], [0], color="#666666", lw=1.2, label="Neighborhood boundaries"),
        Line2D([0], [0], color="black", lw=2.5, label="AOI boundary"),
    ]
    legend_items = [x for x in legend_items if x is not None]
    ax.legend(handles=legend_items, loc="upper right", frameon=True)

    plt.tight_layout()
    plt.show()

    # %% [markdown]
    # * **Connectivity Gap**

    # %%
    records = []

    # Center distrct has the COD_DIS == "01", hence to be sure we filter the ones that meet the condition
    neigh_plot = neigh_aoi.copy()

    # Normalization of COD_DIS to 2 digits
    neigh_plot["COD_DIS"] = neigh_plot["COD_DIS"].astype(str).str.zfill(2)

    # Centro district only
    neigh_plot = neigh_plot[neigh_plot["COD_DIS"] == "01"].copy()

    # Normalization of COD_BAR to 3 digits and sort
    neigh_plot["COD_BAR"] = neigh_plot["COD_BAR"].astype(str).str.zfill(3)
    neigh_plot = neigh_plot.sort_values("COD_BAR")

    # Covered / not covered geometries (unary union)
    covered_geom = None
    if covered is not None:
        if hasattr(covered, "geometry"):            # GeoDataFrame / GeoSeries
            covered_geom = covered.geometry.unary_union
        else:                                      # shapely geometry
            covered_geom = covered

    not_covered_geom = None
    if not_covered is not None:
        if hasattr(not_covered, "geometry"):
            not_covered_geom = not_covered.geometry.unary_union
        else:
            not_covered_geom = not_covered

    # Percentage area covered / not covered by neighborhood
    for _, row in neigh_plot.iterrows():
        name = row[cfg.neigh_col]
        geom = row.geometry

        if geom is None or geom.is_empty:
            continue

        area_total = geom.area
        if area_total == 0:
            continue

        cov_area = geom.intersection(covered_geom).area if covered_geom is not None else 0.0
        noc_area = geom.intersection(not_covered_geom).area if not_covered_geom is not None else 0.0

        records.append({
            cfg.neigh_col: name,
            "COD_BAR": row["COD_BAR"],   # debugging and sorting
            "cov_pct": 100.0 * cov_area / area_total,
            "noc_pct": 100.0 * noc_area / area_total,
        })

    df = pd.DataFrame(records)

    # Prepare for plotting
    plot_df = df.sort_values("COD_BAR").copy()
    x = np.arange(len(plot_df))

    # Plotting phase
    fig, ax = plt.subplots(figsize=(12, 5), dpi=160)

    ax.bar(x, plot_df["cov_pct"], label="Covered", color="#2ca02c")
    ax.bar(x, plot_df["noc_pct"], bottom=plot_df["cov_pct"],
        label="Not covered", color="#d62728")

    ax.set_ylabel("Percentage of area (%)")
    ax.set_title("Accessibility Coverage per Neighborhood (Centro only)")
    ax.set_xticks(x)
    ax.set_xticklabels(plot_df[cfg.neigh_col], rotation=45, ha="right")

    ax.legend()
    plt.tight_layout()
    plt.show()


    # %% [markdown]
    # * **Proposed New Urban Green Spaces**

    # %%
    crs_m = roads_aoi.crs

    def to4326(x):
        if x is None:
            return None
        if isinstance(x, (gpd.GeoDataFrame, gpd.GeoSeries)):
            return x.to_crs(4326)
        return gpd.GeoSeries([x], crs=crs_m).to_crs(4326).iloc[0]

    def add_gj(m, obj, name, style, tooltip=None):
        if obj is None:
            return
        g = to4326(obj)
        if isinstance(g, (gpd.GeoDataFrame, gpd.GeoSeries)) and g.empty:
            return
        if not isinstance(g, gpd.GeoDataFrame):
            g = gpd.GeoDataFrame(geometry=[g], crs=4326)
        folium.GeoJson(
            g.__geo_interface__,
            name=name,
            style_function=lambda f, s=style: s,
            tooltip=(folium.GeoJsonTooltip(fields=[c for c in (tooltip or []) if c in g.columns]) if tooltip else None),
        ).add_to(m)

    def add_pts(m, gdf, name, color, cols):
        if gdf is None or gdf.empty:
            return
        g = gdf.to_crs(4326)
        use = [c for c in cols if c in g.columns]
        fg = folium.FeatureGroup(name=name)
        for r in g.itertuples():
            txt = " | ".join([f"{c}: {getattr(r,c,None)}" for c in use]) if use else None
            folium.CircleMarker(
                [r.geometry.y, r.geometry.x],
                radius=6,
                color=color,
                fill=True,
                fill_opacity=0.9,
                popup=txt
            ).add_to(fg)
        fg.add_to(m)

    def area_m2(obj):
        if obj is None:
            return 0.0
        if isinstance(obj, (gpd.GeoDataFrame, gpd.GeoSeries)):
            if obj.empty:
                return 0.0
            return float(obj.to_crs(crs_m).geometry.area.sum())
        if hasattr(obj, "is_empty") and obj.is_empty:
            return 0.0
        return float(gpd.GeoSeries([obj], crs=crs_m).area.iloc[0])

    # --- map ---
    aoi_4326 = to4326(aoi_geom)
    m = folium.Map([aoi_4326.centroid.y, aoi_4326.centroid.x], tiles="OpenStreetMap", zoom_start=13)

    add_gj(m, aoi_geom, "AOI (Centro)", {"fill": False, "color": "black", "weight": 3})

    add_gj(m, covered,     "Covered (existing)",     {"fillColor": "green",   "color": "green",   "fillOpacity": 0.25, "weight": 1})
    add_gj(m, not_covered, "Not covered (existing)", {"fillColor": "#4C78A8", "color": "#4C78A8", "fillOpacity": 0.35, "weight": 1})

    add_gj(m, selected_pop_iso,  "Scenario 1 — Isochrones (Population)", {"fillColor": "#1f77b4", "color": "#1f77b4", "fillOpacity": 0.18, "weight": 2}, tooltip=["rank","marg_pop"])
    add_gj(m, selected_pop_gain, "Scenario 1 — Gain (Population)",       {"fillColor": "#1f77b4", "color": "#1f77b4", "fillOpacity": 0.35, "weight": 1})
    add_pts(m, selected_pop,     "Scenario 1 — Points (Population)", "#1f77b4", ["rank","marg_pop"])

    add_gj(m, selected_equity_iso,  "Scenario 2 — Isochrones (Equity)", {"fillColor": "#ff7f0e", "color": "#ff7f0e", "fillOpacity": 0.18, "weight": 2}, tooltip=["rank","equitable_score"])
    add_gj(m, selected_equity_gain, "Scenario 2 — Gain (Equity)",       {"fillColor": "#ff7f0e", "color": "#ff7f0e", "fillOpacity": 0.35, "weight": 1})
    add_pts(m, selected_equity,      "Scenario 2 — Points (Equity)", "#ff7f0e", ["rank","equitable_score"])

    b = gpd.GeoSeries([aoi_4326], crs=4326).total_bounds
    m.fit_bounds([[b[1], b[0]], [b[3], b[2]]])
    folium.LayerControl(collapsed=False).add_to(m)

    # --- legend (area + %) ---
    aoi_a  = area_m2(aoi_geom)
    cov_a  = area_m2(covered)
    noc_a  = area_m2(not_covered)
    pga_a  = area_m2(selected_pop_gain)
    ega_a  = area_m2(selected_equity_gain)
    pct = lambda a: (100 * a / aoi_a) if aoi_a else 0.0

    html = f"""
    <div style="position:fixed; bottom:20px; left:20px; z-index:9999; background:white;
    padding:10px 12px; border:1px solid #999; border-radius:6px; font-size:13px;">
    <b>Areas & % of AOI</b><br><br>
    <b>Covered</b>: {cov_a/1e6:.2f} km² ({pct(cov_a):.1f}%)<br>
    <b>Not covered</b>: {noc_a/1e6:.2f} km² ({pct(noc_a):.1f}%)<br>
    <b>Scenario 1 — Gain</b>: {pga_a/1e6:.2f} km² ({pct(pga_a):.1f}%)<br>
    <b>Scenario 2 — Gain</b>: {ega_a/1e6:.2f} km² ({pct(ega_a):.1f}%)
    </div>
    """
    m.get_root().html.add_child(folium.Element(html))

    display(m)


