import pytest
import geopandas as gpd
import pandas as pd
import numpy as np
import networkx as nx
from shapely.geometry import Point, Polygon, LineString
from scipy.spatial import cKDTree

from leafline.assignment01 import (
    compute_existing_coverage,
    pop_sum_within,
    select_top_k_with_min_dist,
    equitable_scoring,
    roads_to_graph,
    generate_candidates,
    build_kdtree_from_nodes,
)


# ============================================================================
# TEST 1: compute_existing_coverage(). Aimed at verifying correct coverage computation.
# ============================================================================

def test_compute_existing_coverage_returns_valid_outputs():
    """Check if the function gives us all 3 outputs required: covered, not_covered, stats. and they make sense."""

    # A road theoretical network is created as a square around a 100x100 area.
    line1 = LineString([(0, 0), (100, 0)])      # Bottom line
    line2 = LineString([(100, 0), (100, 100)])  # Right line
    line3 = LineString([(100, 100), (0, 100)])  # Top line
    line4 = LineString([(0, 100), (0, 0)])      # Left line
    
    # Then each line is added to a GeoDataFrame in the correct CRS.
    roads_gdf = gpd.GeoDataFrame(
        {'road_id': [1, 2, 3, 4]},
        geometry=[line1, line2, line3, line4],
        crs='EPSG:25830'
    )
    
    # An urban green space is created as a square polygon inside the road network.
    green1 = Polygon([(10, 10), (30, 10), (30, 30), (10, 30)])
    green_gdf = gpd.GeoDataFrame(
        {'green_id': [1]},
        geometry=[green1],
        crs='EPSG:25830'
    )
    
    # Fictional Area of Interest (AOI) is defined as the same 100x100 square.
    aoi_geom = Polygon([(0, 0), (100, 0), (100, 100), (0, 100)])
    
    # Setting up configuration parameters for the coverage computation.
    class Config:
        t_min = 5              # 5 minutes walking
        walk_speed_kmh = 5.0   # Walk at 5 km/hour
        hull_ratio = 0.10
        allow_holes = True
    cfg = Config()
    
    # Road network graph is built from the roads GeoDataFrame.
    G = roads_to_graph(roads_gdf)
    nodes, tree = build_kdtree_from_nodes(G)
    
    # Compute existing coverage using the defined parameters and data.
    covered, not_covered, stats = compute_existing_coverage(
        cfg, G, nodes, tree, green_gdf, aoi_geom
    )
    
    # Assertions to verify the outputs are valid and make sense.
    assert covered is not None                          # Got the covered area?
    assert not_covered is not None                      # Got the not covered area?
    assert isinstance(stats, pd.DataFrame)              # Got the statistics table?
    assert len(stats) == 1                              # Table has 1 row?
    
    
# ============================================================================
# TEST 2: pop_sum_within(). Aimed at verifying correct population summation within an area.
# ============================================================================

def test_pop_sum_within_calculates_correctly():
    """ Overall population within an area must be calculated correctly for the analysis of coverage  and uncovered zones."""
    
    # Create population points and values are assigned
    points = [Point(10, 10), Point(20, 20), Point(30, 30), Point(60, 60)]
    pop_gdf = gpd.GeoDataFrame(
        {'VALUE': [100, 200, 300, 400]},
        geometry=points,
        crs='EPSG:25830'
    )
    
    # Area created in which some previous points are located
    area = Polygon([(0, 0), (40, 0), (40, 40), (0, 40)])
    
    # Test the population sum within the area
    result = pop_sum_within(pop_gdf, area, 'VALUE')
    
    # Should be 100 + 200 + 300 = 600 (point at 60,60 is outside)
    assert result == 600.0


# ============================================================================
# TEST 3: select_top_k_with_min_dist(). Aimed at verifying correct selection of top K points with minimum distance constraint.
# ============================================================================

def test_select_top_k_enforces_minimum_distance():
    """Porposed points must respect minimum distance constraint since they are selected from a list of candidates and we don't want to select points that are too close."""
    
    
    # Hypothetical candidate points spaced with 400m intervals. Minimum distance is set to 500m. 
    points = [Point(0, 0), Point(400, 0), Point(800, 0), Point(1200, 0), Point(1600, 0)]
    scores = [100, 90, 80, 70, 60]
    
    candidates_gdf = gpd.GeoDataFrame(
        {'score': scores},
        geometry=points,
        crs='EPSG:25830'
    )
    
    # For instance the setting is to select 3 points with at least 500m apart.
    class Config:
        top_k = 3
        min_dist_m = 500.0
    cfg = Config()
    
    # Testing part - select top K with distance over 500m
    selected = select_top_k_with_min_dist(cfg, candidates_gdf, 'score')
    
    # Check the pairs should present at least a distance of 500m apart
    for i in range(len(selected)):
        for j in range(i + 1, len(selected)):
            dist = selected.iloc[i].geometry.distance(selected.iloc[j].geometry)
            assert dist > 500.0, f"Points {i} and {j} are only {dist}m apart (< 500m)"


# ============================================================================
# TEST 4: equitable_scoring(). Aimed at verifying correct equitable scoring based on underserved populations.
# ============================================================================

def test_equitable_scoring_weights_underserved_higher():
    """Neighborhoods with underserved populations must receive higher weights than those well-served."""
    
    # Create input population in two neighborhoods
    pop_points = [
        Point(25, 25), Point(35, 35),  # In North neighborhood
        Point(75, 75), Point(85, 85)   # In South neighborhood
    ]
    pop_gdf = gpd.GeoDataFrame(
        {'VALUE': [100, 100, 100, 100]},
        geometry=pop_points,
        crs='EPSG:25830'
    )
    
    # Create neighborhoods around the population points
    north_poly = Polygon([(0, 0), (50, 0), (50, 50), (0, 50)])
    south_poly = Polygon([(50, 50), (100, 50), (100, 100), (50, 100)])
    neigh_gdf = gpd.GeoDataFrame(
        {'NOMBRE': ['North', 'South']},
        geometry=[north_poly, south_poly],
        crs='EPSG:25830'
    )
    
    # North is well-covered, South is underserved because only North area is covered with green space
    covered = Polygon([(0, 0), (50, 0), (50, 50), (0, 50)])
    
    # Setting up configuration parameters for equitable scoring.
    class Config:
        neigh_col = 'NOMBRE'
        pop_col = 'VALUE'
    cfg = Config()
    
    # Testing part - compute equitable scoring
    equity = equitable_scoring(cfg, pop_gdf, neigh_gdf, covered)
    
    # Get weights for both neighborhoods according to their coverage status
    north_weight = equity[equity['NOMBRE'] == 'North']['weight'].iloc[0]
    south_weight = equity[equity['NOMBRE'] == 'South']['weight'].iloc[0]
    
    # The neighborhood with underserved population (South) must have a higher weight than the well-served one (North).
    assert south_weight > north_weight, \
        f"Underserved (South) weight {south_weight} must be > served (North) weight {north_weight}"


# ============================================================================
# TEST 5: roads_to_graph(). Aimed at verifying correct conversion of road GeoDataFrame to network graph.
# ============================================================================

def test_roads_to_graph_creates_valid_network():
    """Roads to graph conversion must create a valid network graph, otherwise further analysis can't be performed since network is needed."""
     
    # Road network as three connected lines forming a U shape is created.
    line1 = LineString([(0, 0), (100, 0)])
    line2 = LineString([(100, 0), (100, 100)])
    line3 = LineString([(100, 100), (0, 100)])
    
    roads_gdf = gpd.GeoDataFrame(
        geometry=[line1, line2, line3],
        crs='EPSG:25830'
    )
    
    # Testing part - convert roads to graph
    G = roads_to_graph(roads_gdf)
    
    # Check if G is a valid networkx Graph with nodes and edges
    assert isinstance(G, nx.Graph)
    assert len(G.nodes()) > 0
    assert len(G.edges()) > 0
    
    # Check if all edges have 'weight' attribute and it's positive
    for u, v in G.edges():
        assert 'weight' in G[u][v]
        assert G[u][v]['weight'] > 0


# ============================================================================
# TEST 6: generate_candidates(). Aimed at verifying correct candidate generation in different modes.
# ============================================================================

def test_generate_candidates_random_mode():
    """Generation of candidates in random mode must yield the requested number of candidates within the not covered area."""
        
    # Not covered area polygon
    not_covered = Polygon([(0, 0), (100, 0), (100, 100), (0, 100)])
    
    # Neighborhoods GeoDataFrame with one neighborhood
    neigh_gdf = gpd.GeoDataFrame(
        {'NOMBRE': ['Test']},
        geometry=[Polygon([(0, 0), (50, 0), (50, 50), (0, 50)])],
        crs='EPSG:25830'
    )
    
    # Config for random mode
    class Config:
        mode = "random"
        n_candidates_random = 30
        seed = 42
        max_factor = 1200
    cfg = Config()
    
    # Test part - generate candidates
    candidates = generate_candidates(cfg, not_covered, neigh_gdf)
    
    assert len(candidates) == 30
    assert 'cand_id' in candidates.columns
    
    # All points must be inside not_covered area 
    for geom in candidates.geometry:
        assert not_covered.contains(geom)


def test_generate_candidates_neighborhood_mode():
    """Generation of candidates in neighborhood mode must yield the requested number of points per neighborhood."""
       
    # Not covered area polygon 
    not_covered = Polygon([(0, 0), (100, 0), (100, 100), (0, 100)])
    
    # Two neighborhoods GeoDataFrame
    neigh_gdf = gpd.GeoDataFrame(
        {'NOMBRE': ['North', 'South']},
        geometry=[
            Polygon([(0, 0), (50, 0), (50, 50), (0, 50)]),
            Polygon([(50, 0), (100, 0), (100, 50), (50, 50)])
        ],
        crs='EPSG:25830'
    )
    
    # Config for neighborhood mode
    class Config:
        mode = "neighborhood"
        pts_per_neigh = 5
        neigh_col = 'NOMBRE'
        seed = 42
        max_factor = 1200
    cfg = Config()
    
    # Test part - generate candidates
    candidates = generate_candidates(cfg, not_covered, neigh_gdf)
    
    # Should have 5 points per neighborhood = 10 total
    assert len(candidates) == 10
    assert 'NOMBRE' in candidates.columns
    assert 'cand_id' in candidates.columns
    
    # Check distribution of candidates per neighborhood
    assert len(candidates[candidates['NOMBRE'] == 'North']) == 5
    assert len(candidates[candidates['NOMBRE'] == 'South']) == 5


