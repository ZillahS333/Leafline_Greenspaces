import sys
from pathlib import Path
from unittest import mock

# Add the parent directory to the Python path
sys.path.insert(0, str(Path(__file__).parent.parent))

# Mock the global variables that will be used at module level in Assignment01.py
# This prevents NameError when the module is imported
import builtins
_original_compile = compile

def safe_compile(*args, **kwargs):
    return _original_compile(*args, **kwargs)

# Prevent execution of module-level code that depends on undefined variables
import types

def create_mock_namespace():
    """Create a namespace with commonly needed variables."""
    ns = {}
    return ns

# Import Assignment01 with mocked environment
sys.modules['Assignment01_exec'] = types.ModuleType('Assignment01_exec')